<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('ArtikelModel');
        $this->load->model('DosenModel');
        $this->load->model('AsistenDosenModel');
        $this->load->model('AkunDosenModel');

        if ($this->session->userdata('username') == null) redirect(site_url('auth'));
    }

    public function artikel()
    {
        $data['judul'] = 'Artikel';

        $data['artikel'] = $this->ArtikelModel->get_all();

        $this->load->view('templates/admin_header', $data);
        $this->load->view('templates/admin_sidebar', $data);
        $this->load->view('templates/admin_topbar', $data);
        $this->load->view('admin/artikel', $data);
        $this->load->view('templates/admin_footer', $data);
    }

    public function tambah_artikel()
    {
        if ($this->input->post()) {
            $ext = explode('.', $_FILES["gambar_artikel"]['name']);
            $ext = $ext[count($ext) - 1];
            $new_name = uniqid() . "." . $ext;

            $config['upload_path']          = 'uploads/artikel/';
            $config['allowed_types']        = 'jpg|jpeg|png';
            $config['max_size']             = 2048;
            $config['file_name']            = $new_name;

            $this->load->library('upload', $config);

            $this->upload->initialize($config);

            if (!$this->upload->do_upload("gambar_artikel")) {
                $error = array('error' => $this->upload->display_errors());
                var_dump($error);
                return array("status" => false, "error" => $error);
            }

            $data = [
                "judul_artikel"          => $this->input->post('judul_artikel'),
                "isi_artikel"           => $this->input->post('isi_artikel'),
                "kategori_artikel"      => $this->input->post('kategori_artikel'),
                "gambar_artikel"    => $new_name
            ];


            $this->ArtikelModel->tambah_artikel($data);
            redirect('admin/artikel');
        }
    }

    public function ubah_artikel()
    {
        if ($this->input->post()) {
            if ($_FILES['gambar_artikel']['size'] != 0) {
                $gambar = $this->ArtikelModel->get_by_id($this->input->post('id_artikel'));
                if ($gambar->gambar_artikel != null) {
                    unlink('uploads/artikel/' . $gambar->gambar_artikel);
                }
                $ext = explode('.', $_FILES["gambar_artikel"]['name']);
                $ext = $ext[count($ext) - 1];
                $new_name = uniqid() . "." . $ext;

                $config['upload_path']          = 'uploads/artikel/';
                $config['allowed_types']        = 'jpg|jpeg|png';
                $config['max_size']             = 2048;
                $config['file_name']            = $new_name;

                $this->load->library('upload', $config);

                $this->upload->initialize($config);

                if (!$this->upload->do_upload("gambar_artikel")) {
                    $error = array('error' => $this->upload->display_errors());
                    var_dump($error);
                    return array("status" => false, "error" => $error);
                }

                $data = [
                    "id_artikel"        => $this->input->post('id_artikel'),
                    "judul_artikel"     => $this->input->post('judul_artikel'),
                    "isi_artikel"       => $this->input->post('isi_artikel'),
                    "kategori_artikel"  => $this->input->post('kategori_artikel'),
                    "gambar_artikel"    => $new_name
                ];
            } else {
                $data = [
                    "id_artikel"        => $this->input->post('id_artikel'),
                    "judul_artikel"     => $this->input->post('judul_artikel'),
                    "isi_artikel"       => $this->input->post('isi_artikel'),
                    "kategori_artikel"  => $this->input->post('kategori_artikel')
                ];
            }
            $this->ArtikelModel->ubah_artikel($data);
            redirect('admin/artikel');
        }
    }

    public function hapus_artikel($id)
    {
        $gambar = $this->ArtikelModel->get_by_id($id);
        unlink('uploads/artikel/' . $gambar->gambar_artikel);
        if ($this->ArtikelModel->hapus_artikel($id)) {
            redirect('admin/artikel');
        }
    }

    public function dosen()
    {
        $data['judul'] = 'Dosen';

        $data['dosen'] = $this->DosenModel->get_all();

        $this->load->view('templates/admin_header', $data);
        $this->load->view('templates/admin_sidebar', $data);
        $this->load->view('templates/admin_topbar', $data);
        $this->load->view('admin/dosen', $data);
        $this->load->view('templates/admin_footer', $data);
    }

    public function tambah_dosen()
    {
        if ($this->input->post()) {
            $ext = explode('.', $_FILES["gambar_dosen"]['name']);
            $ext = $ext[count($ext) - 1];
            $new_name = $this->input->post('nip_dosen') . "." . $ext;
            // $new_name = str_replace(" ", "_", $new_name);

            $config['upload_path']          = 'uploads/dosen/';
            $config['allowed_types']        = 'jpg|jpeg|png';
            $config['max_size']             = 2048;
            $config['file_name']            = $new_name;

            $this->load->library('upload', $config);

            $this->upload->initialize($config);

            if (!$this->upload->do_upload("gambar_dosen")) {
                $error = array('error' => $this->upload->display_errors());
                var_dump($error);
                return array("status" => false, "error" => $error);
            }

            $data = [
                "nama_dosen"          => $this->input->post('nama_dosen'),
                "inisial_dosen"          => $this->input->post('inisial_dosen'),
                "nip_dosen"           => $this->input->post('nip_dosen'),
                "email_dosen"      => $this->input->post('email_dosen'),
                "kompetensi_dosen"      => $this->input->post('kompetensi_dosen'),
                "makul_dosen"      => $this->input->post('makul_dosen'),
                "gambar_dosen"    => $new_name
            ];


            $this->DosenModel->tambah_dosen($data);
            redirect('admin/dosen');
        }
    }

    public function ubah_dosen()
    {
        if ($this->input->post()) {
            if ($_FILES['gambar_dosen']['size'] != 0) {
                $gambar = $this->DosenModel->get_by_id($this->input->post('id_dosen'));
                if ($gambar->gambar_dosen != null) {
                    unlink('uploads/dosen/' . $gambar->gambar_dosen);
                }
                $ext = explode('.', $_FILES["gambar_dosen"]['name']);
                $ext = $ext[count($ext) - 1];
                $new_name = $this->input->post('nip_dosen') . "." . $ext;
                // $new_name = str_replace(" ", "_", $new_name);

                $config['upload_path']          = 'uploads/dosen/';
                $config['allowed_types']        = 'jpg|jpeg|png';
                $config['max_size']             = 2048;
                $config['file_name']            = $new_name;

                $this->load->library('upload', $config);

                $this->upload->initialize($config);

                if (!$this->upload->do_upload("gambar_dosen")) {
                    $error = array('error' => $this->upload->display_errors());
                    var_dump($error);
                    return array("status" => false, "error" => $error);
                }

                $data = [
                    "id_dosen"          => $this->input->post('id_dosen'),
                    "nama_dosen"        => $this->input->post('nama_dosen'),
                    "inisial_dosen"          => $this->input->post('inisial_dosen'),
                    "nip_dosen"         => $this->input->post('nip_dosen'),
                    "email_dosen"       => $this->input->post('email_dosen'),
                    "kompetensi_dosen"  => $this->input->post('kompetensi_dosen'),
                    "makul_dosen"       => $this->input->post('makul_dosen'),
                    "gambar_dosen"      => $new_name
                ];
            } else {
                $data = [
                    "id_dosen"          => $this->input->post('id_dosen'),
                    "nama_dosen"        => $this->input->post('nama_dosen'),
                    "inisial_dosen"          => $this->input->post('inisial_dosen'),
                    "nip_dosen"         => $this->input->post('nip_dosen'),
                    "email_dosen"       => $this->input->post('email_dosen'),
                    "kompetensi_dosen"  => $this->input->post('kompetensi_dosen'),
                    "makul_dosen"       => $this->input->post('makul_dosen')
                ];
            }

            // die(var_dump($data));
            $this->DosenModel->ubah_dosen($data);
            redirect('admin/dosen');
        }
    }

    public function hapus_dosen($id)
    {
        $gambar = $this->DosenModel->get_by_id($id);
        unlink('uploads/dosen/' . $gambar->gambar_dosen);
        if ($this->DosenModel->hapus_dosen($id)) {
            redirect('admin/dosen');
        }
    }

    public function asisten_dosen()
    {
        $data['judul'] = 'Asisten Dosen';

        $data['asisten_dosen'] = $this->AsistenDosenModel->get_all();

        $this->load->view('templates/admin_header', $data);
        $this->load->view('templates/admin_sidebar', $data);
        $this->load->view('templates/admin_topbar', $data);
        $this->load->view('admin/asisten_dosen', $data);
        $this->load->view('templates/admin_footer', $data);
    }

    public function tambah_asisten()
    {
        if ($this->input->post()) {
            // $ext = explode('.', $_FILES["gambar_asisten"]['name']);
            // $ext = $ext[count($ext) - 1];
            // $new_name = $this->input->post('nip_dosen') . "." . $ext;
            // $new_name = str_replace(" ", "_", $new_name);

            $config['upload_path']          = 'uploads/ail/';
            $config['allowed_types']        = 'jpg|jpeg|png';
            $config['max_size']             = 2048;
            $config['file_name']            = $_FILES["gambar_asisten"]['name'];

            $this->load->library('upload', $config);

            $this->upload->initialize($config);

            if (!$this->upload->do_upload("gambar_asisten")) {
                $error = array('error' => $this->upload->display_errors());
                var_dump($error);
                return array("status" => false, "error" => $error);
            }

            $data = [
                "nama_asisten"          => $this->input->post('nama_asisten'),
                "makul_asisten"           => $this->input->post('makul_asisten'),
                "gambar_asisten"    => $_FILES["gambar_asisten"]['name']
            ];


            $this->AsistenDosenModel->tambah_asisten_dosen($data);
            redirect('admin/asisten_dosen');
        }
    }

    public function ubah_asisten()
    {
        if ($this->input->post()) {
            if ($_FILES['gambar_asisten']['size'] != 0) {
                $gambar = $this->AsistenDosenModel->get_by_id($this->input->post('id_asisten'));
                if ($gambar->gambar_asisten != null) {
                    unlink('uploads/ail/' . $gambar->gambar_asisten);
                }
                // $ext = explode('.', $_FILES["gambar_dosen"]['name']);
                // $ext = $ext[count($ext) - 1];
                // $new_name = $this->input->post('nip_dosen') . "." . $ext;
                // $new_name = str_replace(" ", "_", $new_name);

                $config['upload_path']          = 'uploads/ail/';
                $config['allowed_types']        = 'jpg|jpeg|png';
                $config['max_size']             = 2048;
                $config['file_name']            = $_FILES["gambar_asisten"]['name'];

                $this->load->library('upload', $config);

                $this->upload->initialize($config);

                if (!$this->upload->do_upload("gambar_asisten")) {
                    $error = array('error' => $this->upload->display_errors());
                    var_dump($error);
                    return array("status" => false, "error" => $error);
                }

                $data = [
                    "id_asisten"            => $this->input->post('id_asisten'),
                    "nama_asisten"          => $this->input->post('nama_asisten'),
                    "makul_asisten"         => $this->input->post('makul_asisten'),
                    "gambar_asisten"        => $_FILES["gambar_asisten"]['name']
                ];
            } else {
                $data = [
                    "id_asisten"            => $this->input->post('id_asisten'),
                    "nama_asisten"          => $this->input->post('nama_asisten'),
                    "makul_asisten"         => $this->input->post('makul_asisten')
                ];
            }

            // die(var_dump($data));
            $this->AsistenDosenModel->ubah_asisten_dosen($data);
            redirect('admin/asisten_dosen');
        }
    }

    public function hapus_asisten_dosen($id)
    {
        $gambar = $this->AsistenDosenModel->get_by_id($id);
        unlink('uploads/ail/' . $gambar->gambar_asisten);
        if ($this->AsistenDosenModel->hapus_asisten_dosen($id)) {
            redirect('admin/asisten_dosen');
        }
    }

    public function akun_dosen()
    {
        $data['judul'] = 'Akun Dosen';

        $data['dosen'] = $this->DosenModel->get_all_dosen_not_registered();
        $data['akun_dosen'] = $this->AkunDosenModel->get_where();

        $this->load->view('templates/admin_header', $data);
        $this->load->view('templates/admin_sidebar', $data);
        $this->load->view('templates/admin_topbar', $data);
        $this->load->view('admin/akun_dosen', $data);
        $this->load->view('templates/admin_footer', $data);
    }

    public function tambah_akun()
    {
        if ($this->input->post()) {
            $data = [
                "id_dosen" => $this->input->post('id_dosen'),
                "password" => $this->input->post('password'),
                "level"    => $this->input->post('level')
            ];
        }
        $this->AkunDosenModel->tambah_akun($data);
        redirect('admin/akun_dosen');
    }

    public function ubah_akun()
    {
        if ($this->input->post()) {
            $data = [
                "id_login_dosen" => $this->input->post('id_login_dosen'),
                "id_dosen" => $this->input->post('id_dosen'),
                "password" => $this->input->post('password'),
                "level"    => $this->input->post('level')
            ];
        }
        $this->AkunDosenModel->ubah_akun($data);
        redirect('admin/akun_dosen');
    }

    public function hapus_akun($id)
    {
        if ($this->AkunDosenModel->hapus_akun($id)) {
            redirect('admin/akun_dosen');
        }
    }
}
