<!-- Start Page Title Area -->
<div class="page-title-area bg-1">
    <div class="container">
        <div class="page-title-content">
            <h2>KURIKULUM</h2>
        </div>
    </div>
</div>
<!-- End Page Title Area -->

<!-- Start Map Area -->
<div class="container">
    <div class="row">
        <div class="col-lg-12 col-md-6 mt-5 mb-5" style="font-family: Open Sans, sans-serif;">
            <h3>Profil Lulusan Program Studi Teknik Informatika</h3>
            <table class="table table-responsive table-bordered font-weight-normal">
                <tr class="text-center">
                    <th>NO</th>
                    <th>PROFIL LULUSAN</th>
                    <th>DESKRIPSI</th>
                    <th>KEMAMPUAN</th>
                </tr>
                <tr>
                    <td>1</td>
                    <td>Software Developer</td>
                    <td class="font-italic">Personal yang memiliki kemampuan merancang dan mengembangkan perangkat lunak berbasis desktop, web, dan mobile serta menerapkan teknik atau metode kecerdasan buatan.</td>
                    <td>
                        <ol style="margin-bottom: 10px;">
                            <li>Mampu mengembangkan perangkat lunak yang sesuai dengan metode pengembangan perangkat lunak yang baku</li>
                            <li>Mampu merancang basis data yang akan digunakan dalam pengembangan perangkat lunak berdasarkan konsep umum pengembangan basis data</li>
                            <li>Mampu merancang antarmuka perangkat lunak yang berpusat kepada kebutuhan pengguna</li>
                            <li>Mampu memodelkan metode ke dalam bahasa pemrograman</li>
                            <li>Mampu menulis kode program dalam pengembangan perangkat lunak berbasis struktural, Object Oriented Programming (OOP) , atau Framework</li>
                            <li>Mampu melakukan pengujian terhadap perangkat lunak berdasarkan standar kualitas yang baku</li>
                            <li>Mampu menganalisis perangkat lunak berdasarkan hasil pengujian yang dilakukan</li>
                        </ol>
                    </td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Multimedia Developer</td>
                    <td class="font-italic">Personal yang memiliki kemampuan untuk merancang, mengimplementasikan, mengembangkan, menguji, menganalisa dan mengoperasikan perangkat multimedia dalam platform yang beragam (seperti simple computer, desktop, web dan mobile) sesuai dengan kebutuhan pengguna akhir.</td>
                    <td>
                        <ol style="margin-bottom: 10px;">
                            <li>Mampu memahami konsep pengembangan produk multimedia seperti animasi, video, grafika, permainan, simulasi dan website.</li>
                            <li>Mampu menjelaskan konsep pengembangan produk multimedia seperti animasi, video, grafika, permainan, simulasi dan website.</li>
                            <li>Mampu merancang produk multimedia dengan memanfaatkan beragam teknik grafis.</li>
                            <li>Mampu mengimplementasikan solusi permasalahan pengguna akhir dalam bentuk purwarupa dan produk multimedia.</li>
                            <li>Mampu mengembangkan purwarupa dan produk multimedia pada platform multimedia yang sesuai dengan kebutuhan pengguna akhir dengan memanfaatkan teknologi multimedia terkini.</li>
                            <li>Mampu menggunakan aplikasi pengembangan perangkat lunak dan perangkat keras pada platform multimedia.</li>
                            <li>Mampu melakukan pengujian dan analisa terhadap purwarupa dan produk multimedia yang dihasilkan, apakah sesuai dengan kebutuhan pengguna akhir.</li>
                        </ol>
                    </td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>IT Infrastructure Engineer</td>
                    <td class="font-italic">Personal yang memiliki kemampuan merancang dan mengembangkan Infrastruktur dan Layanan Jaringan Komputer sampai pada skala Enterprise.</td>
                    <td>
                        <ol style="margin-bottom: 10px;">
                            <li>Mampu mengembangkan dan mengoptimalkan pemanfaatan sistem operasi berbasis Open Source dan Enterprise</li>
                            <li>Mampu merancang dan mengoptimalkan infrastruktur jaringan komputer berbasis kabel dan nirkabel</li>
                            <li>Mampu membangun dan mengembangkan layanan-layanan pada jaringan komputer berbasis open source dan enterprise</li>
                            <li>Mampu membangun dan mengembangkan layanan-layanan infrastruktur jaringan komputer pendukung layanan multimedia.</li>
                            <li>Mampu membangun dan mengembangkan layanan infrastruktur berbasis virtualisasi dan cloud computing</li>
                            <li>Mampu menbangun sistem keamanan infrastruktur jaringan pada jalur kabel dan nirkabel.</li>
                            <li>Mampu mengelola layanan dan infrastuktur jaringan berbasis SOHO dan Provider.</li>
                        </ol>
                    </td>
                </tr>
            </table>
            <h3>Capaian Pembelajaran Lulusan Program Studi Teknik Informatika</h3>
            <table class="table table-bordered">
                <tr class="text-center">
                    <th>NO</th>
                    <th>KOMPONEN CP</th>
                    <th>KODE</th>
                    <th>CAPAIAN PEMBELAJARAN LULUSAN</th>
                </tr>
                <tr>
                    <td>1</td>
                    <td>Sikap</td>
                    <td class="font-weight-bold">S</td>
                    <td>
                        <table>
                            <tr>
                                <td>S01</td>
                                <td>Bertakwa kepada Tuhan Yang Maha Esa dan mampu menunjukkan sikap religius;</td>
                            </tr>
                            <tr>
                                <td>S02</td>
                                <td>Menjunjung tinggi nilai kemanusiaan dalam menjalankan tugas berdasarkan agama,moral, dan etika;</td>
                            </tr>
                            <tr>
                                <td>S03</td>
                                <td>Berkontribusi dalam peningkatan mutu kehidupan bermasyarakat, berbangsa, bernegara, dan kemajuan peradaban berdasarkan Pancasila;</td>
                            </tr>
                            <tr>
                                <td>S04</td>
                                <td>Menghargai keanekaragaman budaya, pandangan, agama, dan kepercayaan, serta pendapat atau temuan orisinal orang lain;</td>
                            </tr>
                            <tr>
                                <td>S05</td>
                                <td>Mampu memilih sumber daya, memanfaatkan perangkat perancangan serta analisis rekayasa berbasis teknologi informasi dan komputasi yang mengacu kepada metode dan standar industri.</td>
                            </tr>
                            <tr>
                                <td>S06</td>
                                <td>Bekerjasama dan memiliki kepekaan sosial serta kepedulian terhadap masyarakat dan lingkungan;</td>
                            </tr>
                            <tr>
                                <td>S07</td>
                                <td>Taat hukum dan disiplin dalam kehidupan bermasyarakat dan bernegara;</td>
                            </tr>
                            <tr>
                                <td>S08</td>
                                <td>Menginternalisasi nilai, norma, dan etika akademik;</td>
                            </tr>
                            <tr>
                                <td>S09</td>
                                <td>Menunjukkan sikap bertanggungjawab atas pekerjaan di bidang keahliannya secara mandiri;</td>
                            </tr>
                            <tr>
                                <td>S10</td>
                                <td>Menginternalisasi semangat kemandirian, kejuangan, dan kewirausahaan.</td>
                            </tr>
                            <tr>
                                <td>S11</td>
                                <td>Berperan sebagai warga negara yang bangga dan cinta tanah air, memiliki nasionalisme serta rasa tanggungjawab pada negara dan bangsa;</td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Keterampilan Umum</td>
                    <td class="font-weight-bold">KU</td>
                    <td>
                        <table>
                            <tr>
                                <td>KU01</td>
                                <td>Kemampuan beradaptasi dalam masyarakat dan lingkungan kerja.</td>
                            </tr>
                            <tr>
                                <td>KU02</td>
                                <td>Kemampuan untuk bertindak dengan kompetensi teknis yang inovatif dalam penggunaan material Teknik Informatika.</td>
                            </tr>
                            <tr>
                                <td>KU03</td>
                                <td>Mampu menyajikan beberapa alternatif solusi dan membuat keputusan pilihan berdasarkan pertimbangan keilmuan Teknik Informatika.</td>
                            </tr>
                            <tr>
                                <td>KU04</td>
                                <td>Kemampuan berkomunikasi dan bekerjasama dalam suatu tim kerja.</td>
                            </tr>
                            <tr>
                                <td>KU05</td>
                                <td>Kemampuan menjunjung tinggi norma, tata nilai, moral,agama, etika dan tanggung jawab sosial.</td>
                            </tr>
                            <tr>
                                <td>KU06</td>
                                <td>Bertanggung jawab pada pekerjaan secara mandiri dan dapat diberi tanggungjawab atas pencapaian hasil kerja kelompok.</td>
                            </tr>
                            <tr>
                                <td>KU07</td>
                                <td>Komunikatif, estetis, etis, apresiatif, partisipatif</td>
                            </tr>
                            <tr>
                                <td>KU08</td>
                                <td>Memiliki pemahaman etika profesional dan kode etik seperti yang diterapkan dalam praktek Teknik Informatika.</td>
                            </tr>
                            <tr>
                                <td>KU09</td>
                                <td>Memiliki pemahaman etika akademik, memiliki pemahaman terhadap nilai-nilai keagamaan dalam masyarakat.</td>
                            </tr>
                            <tr>
                                <td>KU10</td>
                                <td>Memahami peran sebagai warga negara dan mampu menggunakan bahasa nasional dan internasional dalam berkomunikasi.</td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Keterampilan Khusus</td>
                    <td class="font-weight-bold">KK</td>
                    <td>
                        <table>
                            <tr>
                                <td>KK01</td>
                                <td>Mampu menerapkan matematika, statistik dan prinsip rekayasa ke dalam prosedur, proses sistem, atau metodologi rekayasa terapan untuk menyelesaikan masalah.</td>
                            </tr>
                            <tr>
                                <td>KK02</td>
                                <td>Mampu mengindentifikasi, memformulasikan dan melakukan penelusuran referensi, standar baku, pengkodean dan basis data.</td>
                            </tr>
                            <tr>
                                <td>KK03</td>
                                <td>Mampu menganalisis dan menyelesaikan masalah rekayasa dengan menggunakan perangkat analisis untuk satu bidang spesialisasi dengan memperhatikan faktor-faktor ekonomi, kesehatan, dan keselamatan publik, kultural, sosial, dan lingkungan.</td>
                            </tr>
                            <tr>
                                <td>KK04</td>
                                <td>Mampu merancang, membangun dan memelihara proses, produk, purwarupa, infrastruktur dan layanan, yang memenuhi kebutuhan spesifik dengan pertimbangan tepat terhadap masalah, mengacu pada metode dan standar industri.</td>
                            </tr>
                            <tr>
                                <td>KK05</td>
                                <td>Mampu memilih sumber daya, memanfaatkan perangkat perancangan serta analisis rekayasa berbasis teknologi informasi dan komputasi yang mengacu kepada metode dan standar industri.</td>
                            </tr>
                            <tr>
                                <td>KK06</td>
                                <td>Mampu meningkatkan kinerja dan mutu suatu proses melalui pengujian, pengukuran objek kerja, analisis, dan interpretasi data sesuai prosedur dan standar baku.</td>
                            </tr>
                            <tr>
                                <td>KK07</td>
                                <td>Mampu mengkombinasikan teknologi modern dalam melaksanakan pekerjaan.</td>
                            </tr>
                            <tr>
                                <td>KK08</td>
                                <td>Mampu berkomunikasi secara efektif sesuai dengan norma yang berlaku umum.</td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Pengetahuan</td>
                    <td class="font-weight-bold">P</td>
                    <td>
                        <table>
                            <tr>
                                <td>P01</td>
                                <td>Mengkombinasikan konsep teoritis secara umum pada bidang matematika, statistik, prinsip-prinsip rekayasa dan perancangan rekayasa yang diperlukan untuk analisis, perancangan proses, produk, purwarupa, infrastruktur dan layanan.</td>
                            </tr>
                            <tr>
                                <td>P02</td>
                                <td>Memadukan prinsip dan teknik perancangan proses, produk, purwarupa, infrastruktur dan layanan menggunakan teknologi pada tataran terapan.</td>
                            </tr>
                            <tr>
                                <td>P03</td>
                                <td>Menggabungkan konsep teoritis teknologi rekayasa yang diperlukan pada satu bidang spesialisasi.</td>
                            </tr>
                            <tr>
                                <td>P04</td>
                                <td>Merancang penyelesaian masalah rekayasa berdasarkan pengetahuan tentang pengkodean dan standar baku.</td>
                            </tr>
                            <tr>
                                <td>P05</td>
                                <td>Menelaah prinsip dan isu terbaru serta terkini dalam hal perkembangan teknologi, ekonomi, kesehatan, keselamatan publik, kultural,sosial, dan lingkungan secara umum.</td>
                            </tr>
                            <tr>
                                <td>P06</td>
                                <td>Menerapkan prinsip, tata kerja dan kegiatan kelas, laboratorium, serta pelaksanaan keselamatan dan kesehatan kerja (K3).</td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>

            <h3>Rincian Kurikulum</h3>
            <table class="table table-bordered font-weight-normal">
                <tr class="text-center">
                    <th>#</th>
                    <th>SEMESTER</th>
                    <th>JUMLAH (JAM)</th>
                    <th>JUMLAH (SKS)</th>
                    <th>JUMLAH MATA KULIAH</th>
                    <th colspan="2">TEORI VS PRATIKUM</th>
                </tr>
                <tr class="text-center">
                    <td>1</td>
                    <td>Semester 1</td>
                    <td>30</td>
                    <td>24</td>
                    <td>10</td>
                    <td style="width:20% ;">Teori: 18 (60%)</td>
                    <td style="width:20% ;">Praktikum: 12 (40%)</td>
                </tr>
                <tr class="text-center">
                    <td>2</td>
                    <td>Semester 2</td>
                    <td>30</td>
                    <td>22</td>
                    <td>10</td>
                    <td style="width:20% ;">Teori: 14 (46.67%)</td>
                    <td style="width:20% ;">Praktikum: 16 (53.33%)</td>
                </tr>
                <tr class="text-center">
                    <td>3</td>
                    <td>Semester 3</td>
                    <td>34</td>
                    <td>24</td>
                    <td>12</td>
                    <td style="width:20% ;">Teori: 14 (41.18%)</td>
                    <td style="width:20% ;">Praktikum: 20 (58.82%)</td>
                </tr>
                <tr class="text-center">
                    <td>4</td>
                    <td>Semester 4</td>
                    <td>32</td>
                    <td>19</td>
                    <td>11</td>
                    <td style="width:20% ;">Teori: 8 (25%)</td>
                    <td style="width:20% ;">Praktikum: 24 (75%)</td>
                </tr>
                <tr class="text-center">
                    <td>5</td>
                    <td>Semester 5</td>
                    <td>34</td>
                    <td>22</td>
                    <td>11</td>
                    <td style="width:20% ;">Teori: 10 (29.41%)</td>
                    <td style="width:20% ;">Praktikum: 24 (70.59%)</td>
                </tr>
                <tr class="text-center">
                    <td>6</td>
                    <td>Semester 6</td>
                    <td>40</td>
                    <td>6</td>
                    <td>1</td>
                    <td colspan="2" style="width:20% ;">Praktikum: 40 (100%)</td>
                </tr>
                <tr class="text-center">
                    <td>7</td>
                    <td>Semester 7</td>
                    <td>30</td>
                    <td>20</td>
                    <td>10</td>
                    <td style="width:20% ;">Teori: 12 (40%)</td>
                    <td style="width:20% ;">Praktikum: 18 (60%)</td>
                </tr>
                <tr class="text-center">
                    <td>8</td>
                    <td>Semester 8</td>
                    <td>26</td>
                    <td>12</td>
                    <td>4</td>
                    <td style="width:20% ;">Teori: 6 (23.08%)</td>
                    <td style="width:20% ;">Praktikum: 20 (76.92%)</td>
                </tr>
                <tr class="text-center">
                    <td colspan="2" class="font-weight-bold">TOTAL</td>
                    <td class="font-weight-bold">256</td>
                    <td class="font-weight-bold">149</td>
                    <td class="font-weight-bold">69</td>
                    <td>Teori: 82 (32.03%)</td>
                    <td>Praktikum: 174 (67.97%)</td>
                </tr>
            </table>
        </div>
    </div>

    <!-- Semester 1 dan 2 -->
    <div class="row">
        <div class="col-lg-6 col-md-6 mt-5 mb-5" style="font-family: Open Sans, sans-serif;">
            <h3>Semester 1</h3>
            <table class="table table-responsive table-bordered font-weight-normal">
                <tr class="text-center">
                    <th>NO</th>
                    <th>KODE</th>
                    <th>NAMA MATA KULIAH</th>
                    <th>JENIS</th>
                    <th>SKS T</th>
                    <th>SKS P</th>
                    <th>JAM T</th>
                    <th>JAM P</th>
                </tr>
                <tr>
                    <td>1</td>
                    <td>WK407</td>
                    <td>Bahasa Inggris 1</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>WU401</td>
                    <td>Agama</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>TI401</td>
                    <td>Matematika</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>TI403</td>
                    <td>Konsep Teknologi Informasi</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>TI404</td>
                    <td>Algoritma dan Pemrograman</td>
                    <td>Teori</td>
                    <td>4</td>
                    <td></td>
                    <td>4</td>
                    <td></td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>TI405</td>
                    <td>Praktikum Algoritma dan Pemrograman</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>TI406</td>
                    <td>Organisasi dan Arsitektur Komputer</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>TI407</td>
                    <td>Bengkel Pengembangan Web Dasar</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>9</td>
                    <td>TI415</td>
                    <td>Basis Data Dasar</td>
                    <td>Teori</td>
                    <td>4</td>
                    <td></td>
                    <td>4</td>
                    <td></td>
                </tr>
                <tr>
                    <td>10</td>
                    <td>TI416</td>
                    <td>Praktikum Basis Data Dasar</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td colspan="4" class="text-right">Total</td>
                    <td>18</td>
                    <td>6</td>
                    <td>18</td>
                    <td>12</td>
                </tr>
                <tr>
                    <td colspan="4" class="text-right">Total</td>
                    <td colspan="2" class="text-center">24</td>
                    <td colspan="2" class="text-center">30</td>
                </tr>
            </table>
        </div>
        <div class="col-lg-6 col-md-6 mt-5 mb-5" style="font-family: Open Sans, sans-serif;">
            <h3>Semester 2</h3>
            <table class="table table-responsive table-bordered font-weight-normal">
                <tr class="text-center">
                    <th>NO</th>
                    <th>KODE</th>
                    <th>NAMA MATA KULIAH</th>
                    <th>JENIS</th>
                    <th>SKS T</th>
                    <th>SKS P</th>
                    <th>JAM T</th>
                    <th>JAM P</th>
                </tr>
                <tr>
                    <td>1</td>
                    <td>TI402</td>
                    <td>Aljabar Matriks</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>WK408</td>
                    <td>Bahasa Inggris 2</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>TI410</td>
                    <td>Sistem Operasi Dasar</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>TI411</td>
                    <td>Praktikum Sistem Operasi</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>TI412</td>
                    <td>Pemrograman Berorientasi Objek</td>
                    <td>Teori</td>
                    <td>4</td>
                    <td></td>
                    <td>4</td>
                    <td></td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>TI417</td>
                    <td>Bengkel Pengembangan Web Lanjut</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>TI418</td>
                    <td>Interaksi Manusia dan Komputer</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>TI413</td>
                    <td>Praktikum Pemrograman Berorientasi Objek</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>9</td>
                    <td>TI421</td>
                    <td>Basis Data Lanjut</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>10</td>
                    <td>TI422</td>
                    <td>Praktikum Basis Data Lanjut</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td colspan="4">Total</td>
                    <td>14</td>
                    <td>8</td>
                    <td>14</td>
                    <td>16</td>
                </tr>
                <tr>
                    <td colspan="4" class="text-right">Total</td>
                    <td colspan="2" class="text-center">22</td>
                    <td colspan="2" class="text-center">30</td>
                </tr>
            </table>
        </div>
    </div>

    <!-- Semester 3 dan 4 -->
    <div class="row">
        <div class="col-lg-6 col-md-6 mt-5 mb-5" style="font-family: Open Sans, sans-serif;">
            <h3>Semester 3</h3>
            <table class="table table-responsive table-bordered font-weight-normal">
                <tr class="text-center">
                    <th>NO</th>
                    <th>KODE</th>
                    <th>NAMA MATA KULIAH</th>
                    <th>JENIS</th>
                    <th>SKS T</th>
                    <th>SKS P</th>
                    <th>JAM T</th>
                    <th>JAM P</th>
                </tr>
                <tr>
                    <td>1</td>
                    <td>TI409</td>
                    <td>Matematika Diskrit</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>WK409</td>
                    <td>Bahasa Inggris 3</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>TI419</td>
                    <td>Struktur Data</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>TI420</td>
                    <td>Praktikum Struktur Data</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>TI423</td>
                    <td>Rekayasa Perangkat Lunak</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>TI424</td>
                    <td>Praktikum Rekayasa Perangkat Lunak</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>TI425</td>
                    <td>Bengkel Pemrograman Web 1</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>TI426</td>
                    <td>Jaringan Komputer Dasar</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>9</td>
                    <td>TI427</td>
                    <td>Praktikum Jaringan Komputer Dasar</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>10</td>
                    <td>TI428</td>
                    <td>Sistem Operasi Lanjut</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>11</td>
                    <td>TI431</td>
                    <td>Bengkel Data Warehouse</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>12</td>
                    <td>WU402</td>
                    <td>Pancasila</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td colspan="4" class="text-right">Total</td>
                    <td>14</td>
                    <td>10</td>
                    <td>14</td>
                    <td>20</td>
                </tr>
                <tr>
                    <td colspan="4" class="text-right">Total</td>
                    <td colspan="2" class="text-center">24</td>
                    <td colspan="2" class="text-center">34</td>
                </tr>
            </table>
        </div>
        <div class="col-lg-6 col-md-6 mt-5 mb-5" style="font-family: Open Sans, sans-serif;">
            <h3>Semester 4</h3>
            <table class="table table-responsive table-bordered font-weight-normal">
                <tr class="text-center">
                    <th>NO</th>
                    <th>KODE</th>
                    <th>NAMA MATA KULIAH</th>
                    <th>JENIS</th>
                    <th>SKS T</th>
                    <th>SKS P</th>
                    <th>JAM T</th>
                    <th>JAM P</th>
                </tr>
                <tr>
                    <td>1</td>
                    <td>WK410</td>
                    <td>Bahasa Inggris 4</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>WK402</td>
                    <td>Enabling Skill</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>TI429</td>
                    <td>Jaringan Komputer Lanjut</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>TI430</td>
                    <td>Praktikum Jaringan Komputer Lanjut</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>TI433</td>
                    <td>Bengkel Aplikasi Dekstop</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>TI434</td>
                    <td>Animasi Komputer 1 </td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>TI435</td>
                    <td>Kecerdasan Buatan</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>TI436</td>
                    <td>Manajemen Proyek</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>9</td>
                    <td>TI437</td>
                    <td>Praktikum Manajemen Proyek</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>1</td>
                    <td></td>
                    <td>2</td>
                </tr>
                <tr>
                    <td>10</td>
                    <td>TI438</td>
                    <td>Bengkel Digital Video Editing</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>1</td>
                    <td></td>
                    <td>3</td>
                </tr>
                <tr>
                    <td>11</td>
                    <td>TI442</td>
                    <td>Bengkel Pemrograman Framework</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>1</td>
                    <td></td>
                    <td>3</td>
                </tr>
                <tr>
                    <td colspan="4">Total</td>
                    <td>8</td>
                    <td>11</td>
                    <td>8</td>
                    <td>24</td>
                </tr>
                <tr>
                    <td colspan="4" class="text-right">Total</td>
                    <td colspan="2" class="text-center">19</td>
                    <td colspan="2" class="text-center">32</td>
                </tr>
            </table>
        </div>
    </div>

    <!-- Semester 5 dan 6 -->
    <div class="row">
        <div class="col-lg-6 col-md-6 mt-5 mb-5" style="font-family: Open Sans, sans-serif;">
            <h3>Semester 5</h3>
            <table class="table table-responsive table-bordered font-weight-normal">
                <tr class="text-center">
                    <th>NO</th>
                    <th>KODE</th>
                    <th>NAMA MATA KULIAH</th>
                    <th>JENIS</th>
                    <th>SKS T</th>
                    <th>SKS P</th>
                    <th>JAM T</th>
                    <th>JAM P</th>
                </tr>
                <tr>
                    <td>1</td>
                    <td>TI408</td>
                    <td>Probabilitas dan Statistika</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>WK401</td>
                    <td>Kapita Selekta</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>TI439</td>
                    <td>Pemrograman Mobile</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>TI440</td>
                    <td>Bengkel Pemrograman Web 2</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>TI441</td>
                    <td>Bengkel Sistem Informasi Geografis</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>TI443</td>
                    <td>Animasi Komputer 2</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>TI444</td>
                    <td>Administrasi dan Keamanan Jaringan Komputer</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>TI445</td>
                    <td>Praktikum Administrasi dan Keamanan Jaringan Komputer</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>9</td>
                    <td>TI446</td>
                    <td>Pembelajaran Mesin</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>10</td>
                    <td>TI447</td>
                    <td>Pengolahan Citra Digital</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>11</td>
                    <td>TI448</td>
                    <td>Praktikum Pengolahan Citra Digital</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td colspan="4" class="text-right">Total</td>
                    <td>10</td>
                    <td>12</td>
                    <td>10</td>
                    <td>24</td>
                </tr>
                <tr>
                    <td colspan="4" class="text-right">Total</td>
                    <td colspan="2" class="text-center">22</td>
                    <td colspan="2" class="text-center">34</td>
                </tr>
            </table>
        </div>
        <div class="col-lg-6 col-md-6 mt-5 mb-5" style="font-family: Open Sans, sans-serif;">
            <h3>Semester 6</h3>
            <table class="table table-responsive table-bordered font-weight-normal">
                <tr class="text-center">
                    <th>NO</th>
                    <th>KODE</th>
                    <th>NAMA MATA KULIAH</th>
                    <th>JENIS</th>
                    <th>SKS T</th>
                    <th>SKS P</th>
                    <th>JAM T</th>
                    <th>JAM P</th>
                </tr>
                <tr>
                    <td>1</td>
                    <td>WK404</td>
                    <td>Kerja Praktik</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>6</td>
                    <td></td>
                    <td>40</td>
                </tr>
                <tr>
                    <td colspan="4">Total</td>
                    <td>0</td>
                    <td>6</td>
                    <td>0</td>
                    <td>40</td>
                </tr>
                <tr>
                    <td colspan="4" class="text-right">Total</td>
                    <td colspan="2" class="text-center">6</td>
                    <td colspan="2" class="text-center">40</td>
                </tr>
            </table>
        </div>
    </div>

    <!-- Semester 7 dan 8 -->
    <div class="row">
        <div class="col-lg-6 col-md-6 mt-5 mb-5" style="font-family: Open Sans, sans-serif;">
            <h3>Semester 7</h3>
            <table class="table table-responsive table-bordered font-weight-normal">
                <tr class="text-center">
                    <th>NO</th>
                    <th>KODE</th>
                    <th>NAMA MATA KULIAH</th>
                    <th>JENIS</th>
                    <th>SKS T</th>
                    <th>SKS P</th>
                    <th>JAM T</th>
                    <th>JAM P</th>
                </tr>
                <tr>
                    <td>1</td>
                    <td>WU404</td>
                    <td>Bahasa Indonesia</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>TI432</td>
                    <td>Kualitas dan Pengujian Perangkat Lunak</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>WK405</td>
                    <td>Tugas Pendahuluan Proyek Akhir</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>6</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>TI449</td>
                    <td>Pengembangan Permainan</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>TI450</td>
                    <td>Perencanaan Strategis Teknologi Informasi</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>TI451</td>
                    <td>Komputasi Awan</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>TI452</td>
                    <td>Jaringan Multimedia</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>TI453</td>
                    <td>Praktikum Jaringan Multimedia</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>9</td>
                    <td>TI455</td>
                    <td>Etika Profesi</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>10</td>
                    <td>TI456</td>
                    <td>Keamanan Data</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td colspan="4" class="text-right">Total</td>
                    <td>12</td>
                    <td>8</td>
                    <td>12</td>
                    <td>18</td>
                </tr>
                <tr>
                    <td colspan="4" class="text-right">Total</td>
                    <td colspan="2" class="text-center">20</td>
                    <td colspan="2" class="text-center">30</td>
                </tr>
            </table>
        </div>
        <div class="col-lg-6 col-md-6 mt-5 mb-5" style="font-family: Open Sans, sans-serif;">
            <h3>Semester 8</h3>
            <table class="table table-responsive table-bordered font-weight-normal">
                <tr class="text-center">
                    <th>NO</th>
                    <th>KODE</th>
                    <th>NAMA MATA KULIAH</th>
                    <th>JENIS</th>
                    <th>SKS T</th>
                    <th>SKS P</th>
                    <th>JAM T</th>
                    <th>JAM P</th>
                </tr>
                <tr>
                    <td>1</td>
                    <td>WU403</td>
                    <td>Kewarganegaraan</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>WK403</td>
                    <td>Kewirausahaan</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>WK406</td>
                    <td>Proyek Akhir</td>
                    <td>Praktikum</td>
                    <td></td>
                    <td>6</td>
                    <td></td>
                    <td>20</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>TI454</td>
                    <td>Perancangan dan Optimasi Jaringan Komputer</td>
                    <td>Teori</td>
                    <td>2</td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                </tr>
                <tr>
                    <td colspan="4">Total</td>
                    <td>6</td>
                    <td>6</td>
                    <td>6</td>
                    <td>20</td>
                </tr>
                <tr>
                    <td colspan="4" class="text-right">Total</td>
                    <td colspan="2" class="text-center">12</td>
                    <td colspan="2" class="text-center">26</td>
                </tr>
            </table>
        </div>
    </div>
</div>
<!-- End Map Area -->